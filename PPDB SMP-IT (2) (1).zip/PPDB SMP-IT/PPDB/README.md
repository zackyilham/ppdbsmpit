# PSB-Template
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=102)&nbsp;
![MIT](https://badges.frapsoft.com/os/mit/mit.svg?v=103)&nbsp;
![Hits](https://hitcounter.pythonanywhere.com/count/tag.svg?url=https%3A%2F%2Fgithub.com%2Fmuhammadzhuhry%2FPSB-Template)

PSB-Template is a template that was i created use bootstrap, that can be used for the schools that want to create admissions system (online registration system).
